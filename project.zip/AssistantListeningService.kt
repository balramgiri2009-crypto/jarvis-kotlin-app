package com.richassistant.heyricher.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import com.richassistant.heyricher.MainActivity
import com.richassistant.heyricher.R
import java.util.Locale

class AssistantListeningService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private val detector: WakeWordDetector = HeyRicherDetector()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var ttsReady = false
    private var wakeTriggered = false

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        textToSpeech = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) startRecognition()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_STICKY
    }

    private fun startRecognition() {
        if (!isRunning) return
        recognizer?.destroy()
        wakeTriggered = false
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(this)
            it.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                },
            )
        }
    }

    override fun onResults(results: Bundle?) {
        val phrases = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        phrases.firstOrNull { detector.matches(it) }?.let { respondToWakeWord(it) }
        startRecognition()
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val phrases =
            partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        if (!wakeTriggered && phrases.any(detector::matches)) {
            respondToWakeWord(phrases.first())
        }
    }

    private fun respondToWakeWord(heard: String) {
        if (wakeTriggered) return
        wakeTriggered = true
        recognizer?.cancel()
        if (ttsReady) {
            val reply = if (heard.lowercase().contains("hey richer")) {
                "I’m here. What can I help you with?"
            } else {
                "I’m here."
            }
            textToSpeech?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "wake-response")
        }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) textToSpeech?.language = Locale.getDefault()
    }

    override fun onDestroy() {
        isRunning = false
        mainHandler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onReadyForSpeech(params: Bundle?) = Unit
    override fun onBeginningOfSpeech() = Unit
    override fun onRmsChanged(rmsdB: Float) = Unit
    override fun onBufferReceived(buffer: ByteArray?) = Unit
    override fun onEndOfSpeech() = Unit
    override fun onError(error: Int) {
        if (isRunning) {
            mainHandler.postDelayed({ startRecognition() }, RESTART_DELAY_MS)
        }
    }
    override fun onEvent(eventType: Int, params: Bundle?) = Unit

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_LOW,
                ),
            )
        }
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_mic)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setContentIntent(openApp)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    companion object {
        const val ACTION_START = "com.richassistant.heyricher.START"
        const val ACTION_STOP = "com.richassistant.heyricher.STOP"
        private const val CHANNEL_ID = "assistant-listening"
        private const val NOTIFICATION_ID = 1042
        private const val RESTART_DELAY_MS = 500L
        @Volatile var isRunning: Boolean = false
            private set
    }
}