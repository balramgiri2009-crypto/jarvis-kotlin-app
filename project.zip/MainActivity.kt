package com.richassistant.heyricher

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.richassistant.heyricher.assistant.AssistantListeningService

class MainActivity : AppCompatActivity() {
    private lateinit var stateText: TextView
    private lateinit var actionButton: MaterialButton
    private val requestPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasMicrophonePermission()) startListening()
            else stateText.text = getString(R.string.microphone_permission_needed)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildContent())
        if (!AssistantListeningService.isRunning) requestListening()
    }

    private fun buildContent(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            setBackgroundColor(getColor(R.color.richer_sand))
        }
        val eyebrow = TextView(this).apply {
            text = "RICHER ASSISTANT"
            textSize = 13f
            letterSpacing = 0.16f
            setTextColor(getColor(R.color.richer_teal))
        }
        val title = TextView(this).apply {
            text = "A calmer way\nto get things done."
            textSize = 34f
            setTextColor(getColor(R.color.richer_ink))
            setPadding(0, 18, 0, 14)
        }
        val description = TextView(this).apply {
            text = "Say “Hey Richer” whenever you need me. I’ll listen in the background and speak my answer out loud."
            textSize = 17f
            setTextColor(getColor(R.color.richer_ink))
            setLineSpacing(4f, 1f)
        }
        val card = MaterialCardView(this).apply {
            radius = 28f
            cardElevation = 0f
            setCardBackgroundColor(getColor(R.color.richer_mint))
            setContentPadding(24, 24, 24, 24)
        }
        val cardContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        stateText = TextView(this).apply {
            text = getString(R.string.ready_to_listen)
            textSize = 18f
            setTextColor(getColor(R.color.richer_ink))
        }
        val hint = TextView(this).apply {
            text = "The microphone stays active only while the assistant is on."
            textSize = 14f
            setTextColor(getColor(R.color.richer_ink))
            setPadding(0, 8, 0, 0)
        }
        cardContent.addView(stateText)
        cardContent.addView(hint)
        card.addView(cardContent)
        val spacer = LinearLayout.LayoutParams(1, 0, 1f)
        actionButton = MaterialButton(this).apply {
            text = getString(R.string.start_listening)
            setTextColor(getColor(android.R.color.white))
            setBackgroundColor(getColor(R.color.richer_teal))
            setOnClickListener { toggleListening() }
        }
        val settingsButton = MaterialButton(this).apply {
            text = "Speech settings"
            setTextColor(getColor(R.color.richer_teal))
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_TEXT_TO_SPEECH_SETTINGS))
            }
        }
        root.addView(eyebrow)
        root.addView(title)
        root.addView(description)
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 32 })
        root.addView(LinearLayout(this), spacer)
        root.addView(actionButton, LinearLayout.LayoutParams(-1, 56).apply { topMargin = 16 })
        root.addView(settingsButton, LinearLayout.LayoutParams(-1, 56))
        return root
    }

    private fun toggleListening() {
        if (AssistantListeningService.isRunning) stopListening() else requestListening()
    }

    private fun requestListening() {
        val permissions = buildList {
            if (!hasMicrophonePermission()) add(Manifest.permission.RECORD_AUDIO)
            if (android.os.Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.POST_NOTIFICATIONS,
                ) != PackageManager.PERMISSION_GRANTED
            ) add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (permissions.isEmpty()) startListening() else requestPermissions.launch(permissions.toTypedArray())
    }

    private fun startListening() {
        ContextCompat.startForegroundService(
            this,
            Intent(this, AssistantListeningService::class.java).setAction(
                AssistantListeningService.ACTION_START,
            ),
        )
        stateText.text = getString(R.string.listening_for_wake_word)
        actionButton.text = getString(R.string.stop_listening)
    }

    private fun stopListening() {
        stopService(Intent(this, AssistantListeningService::class.java))
        stateText.text = getString(R.string.ready_to_listen)
        actionButton.text = getString(R.string.start_listening)
    }

    private fun hasMicrophonePermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    override fun onResume() {
        super.onResume()
        if (::stateText.isInitialized && AssistantListeningService.isRunning) {
            stateText.text = getString(R.string.listening_for_wake_word)
            actionButton.text = getString(R.string.stop_listening)
        }
    }
}