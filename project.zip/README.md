# Hey Richer

Native Android assistant app in Kotlin.

## Current behavior

- Requests microphone access and the Android 13+ notification permission.
- Starts listening automatically when the app opens after permissions are granted.
- Runs microphone recognition from a foreground service with a persistent notification.
- Watches recognition results for the wake phrase “Hey Richer”.
- Speaks a native Android TTS response when the phrase is detected.
- Keeps wake-word matching behind `WakeWordDetector`, making it straightforward to replace the platform recognizer with an offline engine such as Porcupine or a custom TensorFlow Lite model.

## Open the project

Open `artifacts/hey-richer` in Android Studio and run the `app` configuration on an Android 8.0+ device or emulator with speech recognition available.

## Important limitation

The first build uses Android's `SpeechRecognizer` as a zero-dependency wake phrase detector. It may use the device/network speech service and is not equivalent to a low-power always-on keyword chip. For production always-listening behavior, implement the existing `WakeWordDetector` interface with an offline keyword engine.