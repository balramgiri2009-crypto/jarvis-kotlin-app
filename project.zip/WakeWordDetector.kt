package com.richassistant.heyricher.assistant

interface WakeWordDetector {
    fun matches(text: String): Boolean
}

class HeyRicherDetector : WakeWordDetector {
    override fun matches(text: String): Boolean {
        val normalized = text
            .lowercase()
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        return normalized.contains("hey richer") ||
            normalized.contains("hey richa") ||
            normalized.contains("hey rich")
    }
}