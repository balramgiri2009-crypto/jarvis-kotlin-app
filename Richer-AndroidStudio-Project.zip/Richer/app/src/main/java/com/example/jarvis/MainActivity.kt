package com.example.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var toggleButton: Button
    private var isServiceRunning = false

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
            if (audioGranted) {
                startAssistantService()
            } else {
                Toast.makeText(
                    this,
                    "Microphone permission is required for Richer to function.",
                    Toast.LENGTH_LONG
                ).show()
                statusText.text = "Permission denied.\nRicher cannot listen without microphone access."
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        toggleButton = findViewById(R.id.toggleButton)

        toggleButton.setOnClickListener {
            if (isServiceRunning) {
                stopAssistantService()
            } else {
                checkPermissionsAndStart()
            }
        }

        checkPermissionsAndStart()
    }

    private fun checkPermissionsAndStart() {
        val permissionsNeeded = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionsNeeded.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val notGranted = permissionsNeeded.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (notGranted.isEmpty()) {
            startAssistantService()
        } else {
            requestPermissionLauncher.launch(notGranted.toTypedArray())
        }
    }

    private fun startAssistantService() {
        val serviceIntent = Intent(this, WakeWordService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)
        isServiceRunning = true
        statusText.text = "Richer is active.\nListening for \"Hey Richer\"..."
        toggleButton.text = "Stop Richer"
    }

    private fun stopAssistantService() {
        val serviceIntent = Intent(this, WakeWordService::class.java)
        stopService(serviceIntent)
        isServiceRunning = false
        statusText.text = "Richer is stopped."
        toggleButton.text = "Start Richer"
    }
}
