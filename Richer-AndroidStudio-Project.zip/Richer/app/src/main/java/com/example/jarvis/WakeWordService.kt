package com.example.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class WakeWordService : Service(), TextToSpeech.OnInitListener {

    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var textToSpeech: TextToSpeech
    private lateinit var recognizerIntent: Intent
    private val mainHandler = Handler(Looper.getMainLooper())

    private var currentState = AssistantState.IDLE
    private var isTtsReady = false

    private enum class AssistantState {
        IDLE, LISTENING_FOR_WAKE_WORD, SPEAKING, LISTENING_FOR_COMMAND
    }

    companion object {
        private const val CHANNEL_ID = "richer_assistant_channel"
        private const val NOTIFICATION_ID = 101
        private const val WAKE_WORD_RICHER = "hey richer"
        private const val WAKE_WORD_RICHARD = "hey richard"
        private const val UTTERANCE_WAKE_GREETING = "WAKE_GREETING"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Richer is listening for \"Hey Richer\"..."))

        textToSpeech = TextToSpeech(this, this)

        recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(recognitionListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val hindiResult = textToSpeech.setLanguage(Locale("hi", "IN"))
            if (hindiResult == TextToSpeech.LANG_MISSING_DATA || hindiResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                textToSpeech.setLanguage(Locale.US)
            }
            textToSpeech.setSpeechRate(1.0f)
            textToSpeech.setPitch(1.0f)
            isTtsReady = true

            textToSpeech.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    currentState = AssistantState.SPEAKING
                }

                override fun onDone(utteranceId: String?) {
                    mainHandler.post {
                        if (utteranceId == UTTERANCE_WAKE_GREETING) {
                            startListeningForCommand()
                        } else {
                            startListeningForWakeWord()
                        }
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    mainHandler.post { startListeningForWakeWord() }
                }
            })

            startListeningForWakeWord()
        }
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}

        override fun onError(error: Int) {
            // Common, expected errors when nothing is said (timeout / no match).
            // Restart the appropriate listening cycle instead of freezing.
            mainHandler.postDelayed({
                when (currentState) {
                    AssistantState.LISTENING_FOR_WAKE_WORD -> startListeningForWakeWord()
                    AssistantState.LISTENING_FOR_COMMAND -> {
                        speak(
                            "Sorry Sir, I could not hear a command. Please say Hey Richer again.",
                            "ERROR_RETRY"
                        )
                    }
                    else -> startListeningForWakeWord()
                }
            }, 700)
        }

        override fun onResults(results: Bundle?) {
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val spokenText = matches?.firstOrNull()?.lowercase(Locale.getDefault())?.trim().orEmpty()

            when (currentState) {
                AssistantState.LISTENING_FOR_WAKE_WORD -> handleWakeWordResult(spokenText)
                AssistantState.LISTENING_FOR_COMMAND -> handleCommandResult(spokenText)
                else -> startListeningForWakeWord()
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handleWakeWordResult(text: String) {
        if (text.contains(WAKE_WORD_RICHER) || text.contains(WAKE_WORD_RICHARD)) {
            updateNotification("Wake word detected. Listening to your command...")
            speak("Yes Sir, main aapki kya madad kar sakti hoon?", UTTERANCE_WAKE_GREETING)
        } else {
            startListeningForWakeWord()
        }
    }

    private fun handleCommandResult(text: String) {
        val response = getKnowledgeBaseResponse(text)
        updateNotification("Richer is listening for \"Hey Richer\"...")
        speak(response, "COMMAND_RESPONSE")
    }

    private fun getKnowledgeBaseResponse(rawQuery: String): String {
        val q = rawQuery.lowercase(Locale.getDefault()).trim()
        return when {
            q.isEmpty() ->
                "I did not catch that, sir. Could you please repeat your command?"
            q.contains("hello") || q == "hi" || q.contains("hi ") ->
                "Hello Sir, Richer at your service."
            q.contains("who are you") ->
                "I am Richer, your personal AI assistant, built to serve and assist you."
            q.contains("system status") ->
                "All systems are fully operational, sir. Everything is running smoothly."
            q.contains("time") ->
                "The current time is ${getCurrentTime()}, sir."
            q.contains("date") ->
                "Today's date is ${getCurrentDate()}, sir."
            q.contains("thank") ->
                "You are always welcome, sir."
            else ->
                "I heard you say: $rawQuery. I am sorry, I did not fully understand that command, sir."
        }
    }

    private fun getCurrentTime(): String =
        SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())

    private fun getCurrentDate(): String =
        SimpleDateFormat("EEEE, MMMM dd, yyyy", Locale.getDefault()).format(Date())

    private fun startListeningForWakeWord() {
        currentState = AssistantState.LISTENING_FOR_WAKE_WORD
        mainHandler.post {
            try {
                speechRecognizer.cancel()
                speechRecognizer.startListening(recognizerIntent)
            } catch (e: Exception) {
                mainHandler.postDelayed({ startListeningForWakeWord() }, 1000)
            }
        }
    }

    private fun startListeningForCommand() {
        currentState = AssistantState.LISTENING_FOR_COMMAND
        mainHandler.post {
            try {
                speechRecognizer.cancel()
                speechRecognizer.startListening(recognizerIntent)
            } catch (e: Exception) {
                startListeningForWakeWord()
            }
        }
    }

    private fun speak(text: String, utteranceId: String) {
        if (!isTtsReady) return
        currentState = AssistantState.SPEAKING
        speechRecognizer.cancel()
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
        }
        textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Richer Assistant",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Keeps Richer listening in the background."
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Richer")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        super.onDestroy()
        mainHandler.removeCallbacksAndMessages(null)
        speechRecognizer.destroy()
        textToSpeech.stop()
        textToSpeech.shutdown()
    }
}
