# Richer — Android Voice Assistant (JARVIS-style)

## APK kaise banayein (Build Steps)

1. **Android Studio** open karein (latest stable version, Hedgehog ya newer).
2. `File → Open` se yeh poora `Richer` folder select karein.
3. Android Studio khud Gradle sync karega (internet chahiye first time ke liye —
   dependencies download hongi). Isme 1-5 minute lag sakte hain.
4. Sync complete hone ke baad top menu se:
   `Build → Build Bundle(s) / APK(s) → Build APK(s)`
5. Build complete hone par neeche-right corner mein ek notification aayega —
   `locate` link par click karke aapko APK file mil jayegi, path kuch aisa hoga:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Yeh APK file apne phone mein transfer karke install kar lein
   (Settings mein "Install from unknown sources" allow karna padega).

## Zaroori Note

- Pehli baar app open karne par microphone aur notification permission maangega —
  dono allow karein, warna app kaam nahi karega.
- Oppo/ColorOS jaise phones mein background service ko zinda rakhne ke liye:
  `Settings → Battery → App Battery Management → Richer → Allow background activity`
  manually enable karna padega, warna Android khud service ko kill kar dega
  (yeh OS ki restriction hai, code se bypass nahi ho sakta).
- Wake-word detection continuous `SpeechRecognizer` restart cycles use karta hai
  (short listening bursts), kyunki Android SDK mein koi built-in offline
  hotword-detection API nahi hai. Isliye internet chahiye hoga (Google's speech
  recognizer ke liye), jab tak device mein offline language pack installed na ho.

## Package Structure

```
Richer/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/jarvis/
│       │   ├── MainActivity.kt
│       │   └── WakeWordService.kt
│       └── res/
│           ├── layout/activity_main.xml
│           ├── values/strings.xml
│           ├── values/themes.xml
│           └── mipmap-*/ic_launcher.png
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```
